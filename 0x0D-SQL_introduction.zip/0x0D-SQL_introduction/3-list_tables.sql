-- Lists all the tables of my database in my MySQL server
SHOW TABLES;
