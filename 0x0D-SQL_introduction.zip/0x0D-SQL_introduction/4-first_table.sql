-- creates a table called first_table in my current DB
CREATE TABLE IF NOT EXISTS `first_table` (`id` INT, `name` VARCHAR(256));
